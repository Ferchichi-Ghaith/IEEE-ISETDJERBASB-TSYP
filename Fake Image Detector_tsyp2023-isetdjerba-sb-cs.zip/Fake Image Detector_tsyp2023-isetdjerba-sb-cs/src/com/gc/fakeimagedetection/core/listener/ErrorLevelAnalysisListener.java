package com.gc.fakeimagedetection.core.listener;

import java.awt.image.BufferedImage;

public interface ErrorLevelAnalysisListener {

    public void elaCompleted(BufferedImage image);
}
