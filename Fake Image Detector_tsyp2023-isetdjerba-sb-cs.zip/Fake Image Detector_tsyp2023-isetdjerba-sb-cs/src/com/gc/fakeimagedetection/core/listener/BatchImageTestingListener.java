package com.gc.fakeimagedetection.core.listener;

public interface BatchImageTestingListener {

    public void testingComplete(String result);
}
