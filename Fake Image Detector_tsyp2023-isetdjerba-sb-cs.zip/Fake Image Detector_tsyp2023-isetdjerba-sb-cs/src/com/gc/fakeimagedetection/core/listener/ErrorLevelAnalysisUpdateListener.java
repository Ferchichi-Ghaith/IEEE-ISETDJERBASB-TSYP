package com.gc.fakeimagedetection.core.listener;

public interface ErrorLevelAnalysisUpdateListener {

    public void iterationCompleted(String file, Float percentage);
}
