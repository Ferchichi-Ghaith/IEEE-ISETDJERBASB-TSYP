package com.gc.fakeimagedetection.core.listener;

public interface NeuralNetworkCreationCompleteListener {

    public void networkCreationComplete(Boolean flag);
}
