package com.gc.fakeimagedetection.core.listener;

public interface ThreadCompleteListener {

    void notifyOfThreadComplete(final Thread thread);
}
